/** Automatically generated file. DO NOT MODIFY */
package de.stetro.recapturing;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}