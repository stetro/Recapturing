package de.stetro.recapturing;

/**
 * Enumeration to test different image registration modes
 * 
 * @author Steffen Troester
 * 
 */
public enum RecapturingMode {
	AREA_BASED, FEAUTURE_BASED
}
